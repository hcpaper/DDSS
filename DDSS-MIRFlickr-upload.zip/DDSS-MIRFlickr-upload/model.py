import torch
import torch.nn as nn
from torch.nn import TransformerEncoder, TransformerEncoderLayer, LayerNorm, Dropout, Linear
from torch.nn.functional import normalize
from torch.nn import functional as F
from utils import build_affinity_matrix, sgc_precompute


class SGC(nn.Module):
    def __init__(self, in_fea, out_fea):
        super(SGC, self).__init__()
        self.W = nn.Sequential(
            nn.Linear(in_fea, out_fea),
            nn.PReLU()
        )

    def forward(self, x):
        x = self.W(x)
        return x


class FuseTransEncoder(nn.Module):
    def __init__(self, num_layers, hidden_size, nhead, graph_beta):
        super(FuseTransEncoder, self).__init__()
        encoder_layer = TransformerEncoderLayer(d_model=hidden_size, nhead=nhead, batch_first=False)
        self.transformerEncoder = TransformerEncoder(encoder_layer=encoder_layer, num_layers=num_layers)
        self.d_model = hidden_size
        self.sigal_d = int(self.d_model / 2)
        self.GCNencoderImg = SGC(512, 512)
        self.GCNencoderTxt = SGC(512, 512)
        self.neighbor_num = 20
        self.device = "cuda:0"
        self.graph_beta = graph_beta

    def forward(self, img_feat, txt_feat, tokens):
        adjImg = build_affinity_matrix(img_feat, self.neighbor_num).to(self.device)
        adjTxt = build_affinity_matrix(txt_feat, self.neighbor_num).to(self.device)
        featuresImg, precompute_timeImg = sgc_precompute(img_feat, adjImg)
        featuresTxt, precompute_timeTxt = sgc_precompute(txt_feat, adjTxt)
        h_Img = self.GCNencoderImg(featuresImg).to(self.device)
        h_Txt = self.GCNencoderTxt(featuresTxt).to(self.device)
        graph_Img = normalize(h_Img, p=2, dim=1)
        graph_Txt = normalize(h_Txt, p=2, dim=1)
        encoder_X = self.transformerEncoder(tokens)
        encoder_X_r = encoder_X.reshape(-1, self.d_model)
        encoder_X_r = normalize(encoder_X_r, p=2, dim=1)
        trans_img, trans_txt = encoder_X_r[:, :self.sigal_d], encoder_X_r[:, self.sigal_d:]

        img = self.graph_beta * graph_Img + (1 - self.graph_beta) * trans_img
        txt = self.graph_beta * graph_Txt + (1 - self.graph_beta) * trans_txt
        return img, txt, graph_Img, trans_img, graph_Txt, trans_txt


class ImageInstanceMlp(nn.Module):
    def __init__(self, input_dim, hash_lens, semantic_labels, dim_feedforward=[1024, 128, 1024], dropout=0.1):
        super(ImageInstanceMlp, self).__init__()
        self.fc1 = nn.Linear(input_dim, 4096)
        self.relu = nn.ReLU(inplace=True)
        self.dp = nn.Dropout(0.3)
        self.tohash = nn.Linear(4096, hash_lens)
        self.tanh = nn.Tanh()
        self.tosigmoid = nn.Linear(4096, semantic_labels)
        self.sigmoid = nn.Sigmoid()
    def _ff_block(self, x):
        x = normalize(x, p=2, dim=1)
        feat = self.relu(self.fc1(x))
        hid = self.tohash(self.dp(feat))
        sig = self.tosigmoid(feat)
        sig = self.sigmoid(sig)
        out = self.tanh(hid)
        return out, sig

    def forward(self, X):
        mlp_output, sig = self._ff_block(X)
        mlp_output = normalize(mlp_output, p=2, dim=1)
        sig = normalize(sig, p=2, dim=1)
        return mlp_output, sig


class TextInstanceMlp(nn.Module):
    def __init__(self, input_dim, hash_lens, semantic_labels ,dim_feedforward=[1024, 128, 1024], dropout=0.1):
        super(TextInstanceMlp, self).__init__()
        self.fc1 = nn.Linear(input_dim, 4096)
        self.relu = nn.ReLU(inplace=True)
        self.dp = nn.Dropout(0.3)
        self.tohash = nn.Linear(4096, hash_lens)
        self.tanh = nn.Tanh()
        self.tosigmoid = nn.Linear(4096, semantic_labels)
        self.sigmoid = nn.Sigmoid()
    def _ff_block(self, x):
        x = normalize(x, p=2, dim=1)
        feat = self.relu(self.fc1(x))
        hid = self.tohash(self.dp(feat))
        sig = self.tosigmoid(feat)
        sig = self.sigmoid(sig)
        out = self.tanh(hid)
        return out, sig

    def forward(self, X):
        mlp_output, sig = self._ff_block(X)
        mlp_output = normalize(mlp_output, p=2, dim=1)
        sig = normalize(sig, p=2, dim=1)
        return mlp_output, sig

