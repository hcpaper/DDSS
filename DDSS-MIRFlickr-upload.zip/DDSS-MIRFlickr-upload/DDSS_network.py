import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from evaluate import  calculate_top_map
from load_dataset import  load_dataset
from metric import ContrastiveLoss
from model import FuseTransEncoder, ImageInstanceMlp, TextInstanceMlp
from os import path as osp
from utils import load_checkpoints, save_checkpoints
from torch.optim import lr_scheduler
import time

class Solver(object):
    def __init__(self, config):
        self.batch_size = 128
        self.total_epoch = config.epoch
        self.dataset  = config.dataset
        self.model_dir = ".\checkpoints"

        USE_CUDA = torch.cuda.is_available()
        self.device = torch.device(config.device if USE_CUDA else "cpu")

        self.task = config.task
        self.feat_lens = 512
        self.nbits = config.hash_lens
        num_layers, self.token_size, nhead = 1, 1024, 2
        self.semantic_labels = config.semantic
        self.lambda1 = config.lambda1
        self.lambda2 = config.lambda2
        self.graph_beta = config.graph_beta

        self.FuseTrans = FuseTransEncoder(num_layers, self.token_size, nhead, self.graph_beta).to(self.device)
        self.ImageInstanceMlp = ImageInstanceMlp(self.feat_lens, self.nbits, self.semantic_labels).to(self.device)
        self.TextInstanceMlp = TextInstanceMlp(self.feat_lens, self.nbits, self.semantic_labels).to(self.device)


        paramsFuse_to_update = list(self.FuseTrans.parameters()) 
        paramsImageInstance = list(self.ImageInstanceMlp.parameters())
        paramsTextInstance = list(self.TextInstanceMlp.parameters())

        
        total_param = (sum([param.nelement() for param in paramsFuse_to_update])
                       + sum([param.nelement() for param in paramsImageInstance])
                       + sum([param.nelement() for param in paramsTextInstance]))


        print("total_param:", total_param)
        if self.dataset == "mirflickr":
            self.optimizer_FuseTrans = optim.Adam(paramsFuse_to_update, lr=3e-4, betas=(0.5, 0.999), weight_decay=1e-4)
            self.optimizer_ImageInstanceMlp = optim.Adam(paramsImageInstance, lr=1e-4, betas=(0.5, 0.999))
            self.optimizer_TextInstanceMlp = optim.Adam(paramsTextInstance, lr=1e-4, betas=(0.5, 0.999))
        if self.dataset == "nus-wide":
            self.optimizer_FuseTrans = optim.Adam(paramsFuse_to_update, lr=1e-4, betas=(0.5, 0.999), weight_decay=1e-4)
            self.optimizer_ImageInstanceMlp = optim.Adam(paramsImageInstance, lr=1e-4, betas=(0.5, 0.999))
            self.optimizer_TextInstanceMlp = optim.Adam(paramsTextInstance, lr=1e-4, betas=(0.5, 0.999))
        if self.dataset == "mscoco":
            self.optimizer_FuseTrans = optim.Adam(paramsFuse_to_update, lr=1e-4, betas=(0.5, 0.999), weight_decay=1e-4)
            self.optimizer_ImageInstanceMlp = optim.Adam(paramsImageInstance, lr=1e-3, betas=(0.5, 0.999))
            self.optimizer_TextInstanceMlp = optim.Adam(paramsTextInstance, lr=1e-3, betas=(0.5, 0.999))

        if self.dataset == "mirflickr":
            self.ImageInstanceMlp_scheduler = lr_scheduler.MultiStepLR(self.optimizer_ImageInstanceMlp,milestones=[30,80], gamma=1.2)
            self.TextInstanceMlp_scheduler = lr_scheduler.MultiStepLR(self.optimizer_TextInstanceMlp,milestones=[30,80], gamma=1.2)
        elif self.dataset == "mscoco":
            self.ImageInstanceMlp_scheduler = lr_scheduler.MultiStepLR(self.optimizer_ImageInstanceMlp,milestones=[200], gamma=0.6)
            self.TextInstanceMlp_scheduler = lr_scheduler.MultiStepLR(self.optimizer_TextInstanceMlp,milestones=[200], gamma=0.6)

        data_loader = load_dataset(self.dataset, self.batch_size)
        self.train_loader = data_loader['train']
        self.query_loader = data_loader['query']
        self.retrieval_loader = data_loader['retrieval']
              
        self.ContrastiveLoss = ContrastiveLoss(batch_size=self.batch_size, device=self.device)
     
     
    def train(self):
        if self.task == 0: # train real
            print("Training Fusion Transformer...")
            for epoch in range(self.total_epoch):
                print("epoch:",epoch+1)
                train_loss = self.trainfusion()
                if((epoch+1)%10==0):
                    print("Testing...")
                    img2text, text2img = self.evaluate() 
                    print('I2T:',img2text, ', T2I:',text2img)
            save_checkpoints(self)
           
        elif self.task == 1: # train hash 
            print("Training Hash Fuction...")
            I2T_MAP = []
            T2I_MAP = []
            start_time = time.time()
            for epoch in range(self.total_epoch):
                print("epoch:",epoch+1)
                train_loss = self.trainhash()
                print(train_loss)
                if((epoch+1)%10==0):
                    print("Testing...")
                    img2text, text2img = self.evaluate() 
                    I2T_MAP.append(img2text)
                    T2I_MAP.append(text2img)
                    print('I2T:',img2text, ', T2I:',text2img)
            print(I2T_MAP,T2I_MAP)
            save_checkpoints(self)
            time_elapsed = time.time() - start_time
            print(f'Total Train Time: {int(time_elapsed // 60)}m {int(time_elapsed % 60)}s')
                
        elif self.task == 2: # test real
            file_name = self.dataset + '_fusion.pth'
            ckp_path = osp.join(self.model_dir,'real', file_name)
            load_checkpoints(self, ckp_path)

        elif self.task == 3: # test hash 
            
            file_name = self.dataset + '_hash_' + str(self.nbits)+".pth"
            ckp_path = osp.join(self.model_dir,'hash', file_name)
            load_checkpoints(self, ckp_path)

        print("Final Testing...")
        img2text, text2img = self.evaluate() 
        print('I2T:',img2text, ', T2I:',text2img)
        return (img2text + text2img)/2., img2text, text2img
      
    def evaluate(self):
        self.FuseTrans.eval()
        self.ImageInstanceMlp.eval()
        self.TextInstanceMlp.eval()
        qu_BI, qu_BT, qu_L = [], [], []
        re_BI, re_BT, re_L = [], [], []
      
        with torch.no_grad():
            for _,(data_I, data_T, data_L,_) in enumerate(self.query_loader):
                data_I, data_T = data_I.to(self.device), data_T.to(self.device)
                temp_tokens = torch.concat((data_I, data_T), dim = 1)
                img_query ,txt_query,_,_,_,_ =  self.FuseTrans(data_I, data_T,temp_tokens)
                if self.task == 1 or self.task == 3:
                    img_query, _ = self.ImageInstanceMlp(img_query)
                    txt_query, _ = self.TextInstanceMlp(txt_query)
                img_query, txt_query = img_query.cpu().numpy(), txt_query.cpu().numpy()
                qu_BI.extend(img_query)
                qu_BT.extend(txt_query)
                qu_L.extend(data_L.cpu().numpy())  

            for _,(data_I, data_T, data_L,_) in enumerate(self.retrieval_loader):
                data_I, data_T = data_I.to(self.device), data_T.to(self.device)
                temp_tokens = torch.concat((data_I, data_T), dim = 1)
                img_retrieval ,txt_retrieval,_,_,_,_ =  self.FuseTrans(data_I, data_T,temp_tokens)
                if self.task ==1 or self.task ==3:
                    img_retrieval,_ = self.ImageInstanceMlp(img_retrieval)
                    txt_retrieval,_ = self.TextInstanceMlp(txt_retrieval)
                img_retrieval, txt_retrieval = img_retrieval.cpu().numpy(), txt_retrieval.cpu().numpy()
                re_BI.extend(img_retrieval)
                re_BT.extend(txt_retrieval)
                re_L.extend(data_L.cpu().numpy())
        
        re_BI = np.array(re_BI)
        re_BT = np.array(re_BT)
        re_L = np.array(re_L)

        qu_BI = np.array(qu_BI)
        qu_BT = np.array(qu_BT)
        qu_L = np.array(qu_L)

        if self.task ==1 or self.task ==3:   # hashing
            qu_BI = torch.sign(torch.tensor(qu_BI)).cpu().numpy()
            qu_BT = torch.sign(torch.tensor(qu_BT)).cpu().numpy()
            re_BT = torch.sign(torch.tensor(re_BT)).cpu().numpy()
            re_BI = torch.sign(torch.tensor(re_BI)).cpu().numpy()
        elif self.task ==0 or self.task ==2:  # real value
            qu_BI = torch.tensor(qu_BI).cpu().numpy()
            qu_BT = torch.tensor(qu_BT).cpu().numpy()
            re_BT = torch.tensor(re_BT).cpu().numpy()
            re_BI = torch.tensor(re_BI).cpu().numpy()
        
        MAP_I2T = calculate_top_map(qu_B=qu_BI, re_B=re_BT, qu_L=qu_L, re_L=re_L, topk=50)
        MAP_T2I = calculate_top_map(qu_B=qu_BT, re_B=re_BI, qu_L=qu_L, re_L=re_L, topk=50)
        return MAP_I2T, MAP_T2I 
    
    def trainfusion(self):
        self.FuseTrans.train()
        running_loss = 0.0
        for idx, (img, txt, _,_) in enumerate(self.train_loader):
            temp_tokens = torch.concat((img, txt), dim = 1).to(self.device)
            temp_tokens = temp_tokens.unsqueeze(0)
            img_embedding, text_embedding = self.FuseTrans(temp_tokens)
            loss = self.ContrastiveLoss(img_embedding, text_embedding)
            self.optimizer_FuseTrans.zero_grad()
            loss.backward()
            self.optimizer_FuseTrans.step()
            running_loss += loss.item()
        return running_loss
    
    def trainhash(self):
        self.FuseTrans.train()
        self.ImageInstanceMlp.train()
        self.TextInstanceMlp.train()

        running_loss = 0.0
        for idx, (img, txt, _,_) in enumerate(self.train_loader):
            img, txt = img.to(self.device), txt.to(self.device)
            temp_tokens = torch.concat((img, txt), dim = 1)
            temp_tokens = temp_tokens.unsqueeze(0)
            (img_embedding_first, text_embedding_first, img_graph_embedding, img_trans_embedding, text_graph_embedding,
             text_trans_embedding) = self.FuseTrans(img, txt, temp_tokens)
            loss1_cross = self.ContrastiveLoss(img_embedding_first, text_embedding_first)
            loss1_inner_img = self.ContrastiveLoss.forward_feature(img_embedding_first.T, img_trans_embedding.T) + self.ContrastiveLoss.forward_feature(img_embedding_first.T, img_graph_embedding.T)
            loss1_inner_txt = self.ContrastiveLoss.forward_feature(text_embedding_first.T, text_trans_embedding.T) + self.ContrastiveLoss.forward_feature(text_embedding_first.T, text_graph_embedding.T)
            loss1_inner = loss1_inner_txt + loss1_inner_img
            img_embedding,img_semantic = self.ImageInstanceMlp(img_embedding_first)
            text_embedding,text_semantic = self.TextInstanceMlp(text_embedding_first)
            loss2 = self.ContrastiveLoss(img_embedding, text_embedding)

            loss3 = self.ContrastiveLoss(img_semantic, text_semantic)

            loss = loss1_cross + loss1_inner  + loss2*self.lambda1 + loss3*self.lambda2


            self.optimizer_FuseTrans.zero_grad()
            self.optimizer_ImageInstanceMlp.zero_grad()
            self.optimizer_TextInstanceMlp.zero_grad()
            loss.backward()
            self.optimizer_FuseTrans.step()
            self.optimizer_ImageInstanceMlp.step()
            self.optimizer_TextInstanceMlp.step()
            running_loss += loss.item()


            self.ImageInstanceMlp_scheduler.step()
            self.TextInstanceMlp_scheduler.step()
        return running_loss